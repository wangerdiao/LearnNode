create database bankcard
on
(name = 'bankcard_data',
filename = 'F:\SQL\data\bankcard_data.mdf',
size = 10mb,
maxsize=unlimited,
filegrowth=20%)
log on
(name='bankcard_log',
filename='F:\SQL\data\bankcard_log.ldf',
size=10mb,
maxsize=50mb,
filegrowth=1)