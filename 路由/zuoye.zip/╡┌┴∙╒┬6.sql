create database Student
on
(name = 'st1_data',
filename = 'F:\SQL\data\st1_data.mdf',
size=20mb,
maxsize=unlimited,
filegrowth = 1),
filegroup fg1
(name ='st2_data',
filename='F:\SQL\data\st2_data.ndf',
size=20mb,
maxsize=unlimited),
(name ='st3_data',
filename='F:\SQL\data\st3_data.ndf',
size=20mb,
maxsize=20mb)
log on 
(name = 'st1_log',
filename='F:\SQL\data\st1_log.ldf',
size=10mb,
maxsize=unlimited,
filegrowth=1),
(name = 'st2_log',
filename='F:\SQL\data\st2_log.ldf',
size=10mb,
maxsize=unlimited,
filegrowth=1)