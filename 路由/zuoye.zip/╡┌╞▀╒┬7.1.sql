use bankcard
create table depositor
	(IDNO char(18) not null primary key,
	 Dname nvarchar(10) not null,
	 Telephone char(11) not null
	 check(Telephone like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
	 VIP nchar(1) not null check(VIP='��' or VIP='��'))