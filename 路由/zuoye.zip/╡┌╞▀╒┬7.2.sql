use bankcard
create table account
	(accno char(20) primary key not null check(accno like
	'[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]
	[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
	Indo char(18) not null foreign key references depositor(idno),
	Password char(6) not null check(password like '[0-9][0-9][0-9][0-9][0-9][0-9]'),
	Opendate date not null default getdate(),
	Cardtype nchar(3) not null check(cardtype in('���ÿ�','��ǿ�','����')),
	Moneytype nvarchar(10) not null,
	Balance money not null,
		ExpiryDate date not null )