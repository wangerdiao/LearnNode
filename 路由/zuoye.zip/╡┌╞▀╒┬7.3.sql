
use bankcard
create table trecord
	(ID int primary key not null identity(1,1),
	 Tdate date not null default getdate(),
	 Accno char(20) not null foreign key references account(accno),
	 Expense money,
	 Income money,
	 Oppaccno char(20) check(oppaccno>='0000000000000000000' and oppaccno<='99999999999999999999')
	 foreign key references account(accno),
	 Place nvarchar(30),
	 abstruct nvarchar(20) check(abstruct in('ת��','����','����','ATMȡ��','����')
	 ))
